a) Run the RtkBtfilterAutoLogEnable.bat(right click and select run as administrator) , then restart system
b) Run the test
c) After test finished, run the RtkBtfilterAutoLogDisable.bat (right click and select run as administrator)
d) Please send the files located in the folder “C:\ProgramData\Realtek\” to us. 
Please note that "C:\ProgramData" is a hidden folder. Additionally, please inform us of the specific time at which the issue occurred.